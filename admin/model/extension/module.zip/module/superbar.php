<?php
class ModelExtensionModuleSuperbar extends Model {
	public function createTables() {

	}
}
